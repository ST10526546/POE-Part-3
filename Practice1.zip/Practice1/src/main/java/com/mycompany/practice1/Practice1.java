package com.mycompany.practice1;

// =========================================================
// IMPORTS
// =========================================================

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


public class Practice1 {

    // =====================================================
    // GLOBAL VARIABLES
    // =====================================================

    /*
     * Scanner object used throughout the program
     * for collecting user input.
     */
    private static final Scanner scanner = new Scanner(System.in);

    /*
     * Stores registered username and password.
     * These values are captured during registration
     * and used during login.
     */
    private static String registeredUsername;
    private static String registeredPassword;

    /*
     * Stores the maximum number of messages
     * the user wants to send.
     */
    private static int maxMessages;

    // =====================================================
    // MAIN METHOD
    // =====================================================

    public static void main(String[] args) {

        System.out.println("=================================================");
        System.out.println("                  QUICKCHAT");
        System.out.println("=================================================");

        // Register a new user
        registerUser();

        // Login after registration
        if (!loginUser()) {

            System.out.println("Too many failed login attempts.");

            scanner.close();

            return;
        }

        System.out.println("\nWelcome to QuickChat.");

        // Ask user how many messages may be sent
        setMessageLimit();

        boolean running = true;

        // =================================================
        // MAIN MENU LOOP
        // =================================================

        while (running) {

            System.out.println("\n=================================================");
            System.out.println("1) Send Messages");
            System.out.println("2) Show Recently Sent Messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Quit");
            System.out.println("=================================================");

            System.out.print("Choose option: ");

            String option = scanner.nextLine();

            switch (option) {

                // =========================================
                // SEND MESSAGE
                // =========================================
                case "1":

                    /*
                     * Prevent user from sending more than
                     * the specified message limit.
                     */
                    if (Message.getTotalMessages() >= maxMessages) {

                        System.out.println(
                                "You have reached your message limit."
                        );

                        break;
                    }

                    Message message = new Message();

                    message.createMessage();

                    break;

                // =========================================
                // SHOW RECENTLY SENT MESSAGES
                // =========================================
                case "2":

                    Message.displayRecentlySentMessages();

                    break;

                // =========================================
                // STORED MESSAGES MENU
                // =========================================
                case "3":

                    Message.storedMessagesMenu();

                    break;

                // =========================================
                // QUIT APPLICATION
                // =========================================
                case "4":

                    running = false;

                    System.out.println(
                            "\nTotal messages sent: "
                            + Message.getSentMessageCount()
                    );

                    /*
                     * Automatically save all messages
                     * to JSON before closing.
                     */
                    Message.saveMessagesToJSON();

                    System.out.println("Goodbye!");

                    break;

                // =========================================
                // INVALID OPTION
                // =========================================
                default:

                    System.out.println("Invalid option.");
            }
        }

        scanner.close();
    }

    // =====================================================
    // USER REGISTRATION
    // =====================================================

    private static void registerUser() {

        System.out.println("\n---------------- REGISTER ----------------");

        while (true) {

            // Collect username
            System.out.print("Create username: ");

            String username = scanner.nextLine().trim();

            /*
             * Username requirements:
             *
             * Must contain an underscore (_)
             * Must not exceed 5 characters
             */
            if (!username.contains("_") || username.length() > 5) {

                System.out.println(
                        "Username is not correctly formatted; "
                        + "please ensure that your username "
                        + "contains an underscore and is no more "
                        + "than five characters in length."
                );

                continue;
            }

            // Collect password
            System.out.print("Create password: ");

            String password = scanner.nextLine().trim();

            /*
             * Validate password according to assignment:
             *
             * Minimum 8 characters
             * Capital letter
             * Number
             * Special character
             */
            if (!isValidPassword(password)) {

                System.out.println(
                        "Password is not correctly formatted; "
                        + "please ensure that the password "
                        + "contains at least eight characters, "
                        + "a capital letter, a number, and "
                        + "a special character."
                );

                continue;
            }

            // Store valid credentials
            registeredUsername = username;
            registeredPassword = password;

            System.out.println("Username successfully captured.");
            System.out.println("Password successfully captured.");

            break;
        }
    }

    // =====================================================
    // LOGIN USER
    // =====================================================

    private static boolean loginUser() {

        System.out.println("\n---------------- LOGIN ----------------");

        int attempts = 3;

        while (attempts > 0) {

            System.out.print("Username: ");

            String username = scanner.nextLine().trim();

            System.out.print("Password: ");

            String password = scanner.nextLine().trim();

            /*
             * Login successful if username
             * and password match registration.
             */
            if (username.equals(registeredUsername)
                    && password.equals(registeredPassword)) {

                System.out.println("Login successful!");

                return true;
            }

            attempts--;

            System.out.println("Incorrect credentials.");

            System.out.println(
                    "Attempts remaining: "
                    + attempts
            );
        }

        return false;
    }

    // =====================================================
    // PASSWORD VALIDATION METHOD
    // =====================================================

    /*
     * Checks that password contains:
     *
     * - One uppercase letter
     * - One digit
     * - One special character
     * - Minimum length of 8
     */
    private static boolean isValidPassword(String password) {

        return password.matches(
                "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$"
        );
    }

    // =====================================================
    // ASK USER FOR MESSAGE LIMIT
    // =====================================================

    private static void setMessageLimit() {

        while (true) {

            try {

                System.out.print(
                        "\nHow many messages would you like to send? "
                );

                maxMessages = Integer.parseInt(
                        scanner.nextLine()
                );

                if (maxMessages <= 0) {

                    System.out.println(
                            "Please enter a valid positive number."
                    );

                    continue;
                }

                break;

            } catch (NumberFormatException e) {

                System.out.println("Invalid number.");
            }
        }
    }

    // =====================================================
    // MESSAGE CLASS
    // =====================================================

    static class Message {

        /*
         * Random object used to generate
         * unique message IDs.
         */
        private static final Random random = new Random();

        // =================================================
        // REQUIRED PART 3 ARRAYS
        // =================================================

        /*
         * Stores all sent messages.
         */
        private static final List<String> sentMessagesArray =
                new ArrayList<>();

        /*
         * Stores all disregarded messages.
         */
        private static final List<String> disregardedMessagesArray =
                new ArrayList<>();

        /*
         * Stores all stored messages.
         */
        private static final List<String> storedMessagesArray =
                new ArrayList<>();

        /*
         * Stores all message hashes.
         */
        private static final List<String> messageHashesArray =
                new ArrayList<>();

        /*
         * Stores all message IDs.
         */
        private static final List<String> messageIDsArray =
                new ArrayList<>();

        // =================================================
        // SENT MESSAGE ARRAYS
        // =================================================

        private static final List<String> sentMessageTexts =
                new ArrayList<>();

        private static final List<String> sentRecipients =
                new ArrayList<>();

        private static final List<String> sentMessageIDs =
                new ArrayList<>();

        private static final List<String> sentMessageHashes =
                new ArrayList<>();

        // =================================================
        // DISREGARDED MESSAGE ARRAYS
        // =================================================

        private static final List<String> disregardedMessageTexts =
                new ArrayList<>();

        private static final List<String> disregardedRecipients =
                new ArrayList<>();

        private static final List<String> disregardedMessageIDs =
                new ArrayList<>();

        private static final List<String> disregardedMessageHashes =
                new ArrayList<>();

        // =================================================
        // STORED MESSAGE ARRAYS
        // =================================================

        private static final List<String> storedMessageTexts =
                new ArrayList<>();

        private static final List<String> storedRecipients =
                new ArrayList<>();

        private static final List<String> storedMessageIDs =
                new ArrayList<>();

        private static final List<String> storedMessageHashes =
                new ArrayList<>();

        /*
         * Added for Part 3 requirement:
         * Display sender and recipient.
         */
        private static final List<String> storedSenders =
                new ArrayList<>();

        // =================================================
        // LEGACY MESSAGE OBJECT LISTS
        // =================================================

        private static final List<Message> sentMessages =
                new ArrayList<>();

        private static final List<Message> storedMessages =
                new ArrayList<>();

        /*
         * Global counter used when generating
         * message hashes.
         */
        private static int messageCounter = 0;

        // =================================================
        // MESSAGE INSTANCE VARIABLES
        // =================================================

        private final String messageID;
        private final int messageNumber;

        private String sender;
        private String recipient;
        private String messageText;
        private String messageHash;
        private String status;

        // =================================================
        // CONSTRUCTOR
        // =================================================

        public Message() {

            this.messageID = generateMessageID();

            this.messageNumber = ++messageCounter;

            /*
             * Sender is automatically the
             * currently logged-in user.
             */
            this.sender = registeredUsername;
        }

        // =================================================
        // GENERATE RANDOM 10-DIGIT MESSAGE ID
        // =================================================

        private String generateMessageID() {

            long number =
                    1000000000L
                    + (long) (random.nextDouble()
                    * 9000000000L);

            String generatedID = String.valueOf(number);

            System.out.println(
                    "Message ID generated: "
                    + generatedID
            );

            return generatedID;
        }
                // =================================================
        // CREATE MESSAGE
        // =================================================

        /*
         * Controls the complete message creation process.
         *
         * Steps:
         * 1. Capture recipient
         * 2. Capture message text
         * 3. Generate message hash
         * 4. Allow user to choose action
         */
        public void createMessage() {

            captureRecipient();

            if (!captureMessageText()) {
                return;
            }

            createMessageHash();

            System.out.println(
                    "Message Hash: "
                    + messageHash
            );

            chooseMessageAction();
        }

        // =================================================
        // RECIPIENT VALIDATION
        // =================================================

        /*
         * Validates international phone number format.
         *
         * Example:
         * +27123456789
         */
        private void captureRecipient() {

            while (true) {

                System.out.print(
                        "Recipient number (+27123456789): "
                );

                String input =
                        scanner.nextLine().trim();

                if (!input.matches(
                        "^\\+[1-9]\\d{9,14}$"
                )) {

                    System.out.println(
                            "Cell phone number is incorrectly "
                            + "formatted or does not contain "
                            + "an international code. "
                            + "Please correct the number "
                            + "and try again."
                    );

                    continue;
                }

                recipient = input;

                System.out.println(
                        "Cell phone number successfully captured."
                );

                break;
            }
        }

        // =================================================
        // MESSAGE VALIDATION
        // =================================================

        /*
         * Assignment requirement:
         * Maximum message length = 250 characters
         */
        private boolean captureMessageText() {

            System.out.print(
                    "Enter message (max 250 characters): "
            );

            String input =
                    scanner.nextLine().trim();

            if (input.isBlank()) {

                System.out.println(
                        "Message cannot be empty."
                );

                return false;
            }

            if (input.length() > 250) {

                int excess =
                        input.length() - 250;

                System.out.println(
                        "Message exceeds 250 characters by "
                        + excess
                        + ", please reduce the size."
                );

                return false;
            }

            messageText = input;

            System.out.println(
                    "Message ready to send."
            );

            return true;
        }

        // =================================================
        // GENERATE MESSAGE HASH
        // =================================================

        /*
         * Hash Format:
         *
         * First 2 digits of Message ID
         * :
         * Message Number
         * :
         * First Word + Last Word
         *
         * Example:
         *
         * 12:1:HELLOWORLD
         */
        private void createMessageHash() {

            String[] words =
                    messageText.split("\\s+");

            String firstWord =
                    words[0];

            String lastWord =
                    words.length > 1
                    ? words[words.length - 1]
                    : "";

            messageHash =
                    (
                            messageID.substring(0, 2)
                            + ":"
                            + messageNumber
                            + ":"
                            + firstWord
                            + lastWord
                    ).toUpperCase();
        }

        // =================================================
        // MESSAGE ACTION MENU
        // =================================================

        /*
         * User chooses whether to:
         *
         * 1. Send Message
         * 2. Disregard Message
         * 3. Store Message
         */
        private void chooseMessageAction() {

            while (true) {

                System.out.println(
                        "\nChoose an option:"
                );

                System.out.println(
                        "1) Send Message"
                );

                System.out.println(
                        "2) Disregard Message"
                );

                System.out.println(
                        "3) Store Message to send later"
                );

                System.out.print(
                        "Choice: "
                );

                String option =
                        scanner.nextLine();

                switch (option) {

                    // =====================================
                    // SEND MESSAGE
                    // =====================================
                    case "1":

                        status = "Sent";

                        /*
                         * Add Message Object
                         */
                        sentMessages.add(this);

                        /*
                         * Populate Sent Arrays
                         */
                        sentMessageTexts.add(messageText);
                        sentRecipients.add(recipient);
                        sentMessageIDs.add(messageID);
                        sentMessageHashes.add(messageHash);

                        /*
                         * Populate Assignment Arrays
                         */
                        sentMessagesArray.add(messageText);

                        messageHashesArray.add(
                                messageHash
                        );

                        messageIDsArray.add(
                                messageID
                        );

                        System.out.println(
                                "Message successfully sent."
                        );

                        displayMessage();

                        return;

                    // =====================================
                    // DISREGARD MESSAGE
                    // =====================================
                    case "2":

                        status = "Disregarded";

                        /*
                         * Populate Disregarded Arrays
                         */
                        disregardedMessageTexts.add(
                                messageText
                        );

                        disregardedRecipients.add(
                                recipient
                        );

                        disregardedMessageIDs.add(
                                messageID
                        );

                        disregardedMessageHashes.add(
                                messageHash
                        );

                        /*
                         * Populate Assignment Arrays
                         */
                        disregardedMessagesArray.add(
                                messageText
                        );

                        messageHashesArray.add(
                                messageHash
                        );

                        messageIDsArray.add(
                                messageID
                        );

                        System.out.println(
                                "Press 0 to delete the message."
                        );

                        String delete =
                                scanner.nextLine();

                        if (delete.equals("0")) {

                            System.out.println(
                                    "Message discarded."
                            );
                        }

                        return;

                    // =====================================
                    // STORE MESSAGE
                    // =====================================
                    case "3":

                        status = "Stored";

                        /*
                         * Store Message Object
                         */
                        storedMessages.add(this);

                        /*
                         * Populate Stored Arrays
                         */
                        storedMessageTexts.add(
                                messageText
                        );

                        storedRecipients.add(
                                recipient
                        );

                        storedMessageIDs.add(
                                messageID
                        );

                        storedMessageHashes.add(
                                messageHash
                        );

                        storedSenders.add(
                                sender
                        );

                        /*
                         * Populate Assignment Arrays
                         */
                        storedMessagesArray.add(
                                messageText
                        );

                        messageHashesArray.add(
                                messageHash
                        );

                        messageIDsArray.add(
                                messageID
                        );

                        System.out.println(
                                "Message successfully stored."
                        );

                        return;

                    // =====================================
                    // INVALID OPTION
                    // =====================================
                    default:

                        System.out.println(
                                "Invalid option."
                        );
                }
            }
        }

        // =================================================
        // DISPLAY MESSAGE DETAILS
        // =================================================

        /*
         * Displays full message information
         * after sending.
         */
        private void displayMessage() {

            System.out.println(
                    "\n============= MESSAGE DETAILS ============="
            );

            System.out.println(
                    "Sender       : "
                    + sender
            );

            System.out.println(
                    "Message ID   : "
                    + messageID
            );

            System.out.println(
                    "Message Hash : "
                    + messageHash
            );

            System.out.println(
                    "Recipient    : "
                    + recipient
            );

            System.out.println(
                    "Message      : "
                    + messageText
            );

            System.out.println(
                    "Status       : "
                    + status
            );
        }

        // =================================================
        // DISPLAY RECENTLY SENT MESSAGES
        // =================================================

        /*
         * Part 3 Menu Option:
         *
         * Show Recently Sent Messages
         */
        public static void displayRecentlySentMessages() {

            if (sentMessageTexts.isEmpty()) {

                System.out.println(
                        "No sent messages available."
                );

                return;
            }

            System.out.println(
                    "\n=========== RECENTLY SENT MESSAGES ==========="
            );

            for (int i = 0;
                    i < sentMessageTexts.size();
                    i++) {

                System.out.println(
                        "\nMessage " + (i + 1)
                );

                System.out.println(
                        "Recipient : "
                        + sentRecipients.get(i)
                );

                System.out.println(
                        "Message   : "
                        + sentMessageTexts.get(i)
                );

                System.out.println(
                        "Message ID: "
                        + sentMessageIDs.get(i)
                );

                System.out.println(
                        "Hash      : "
                        + sentMessageHashes.get(i)
                );

                System.out.println(
                        "-------------------------------------"
                );
            }
        }
                // =================================================
        // STORED MESSAGES MENU
        // =================================================

        public static void storedMessagesMenu() {

            loadStoredMessagesFromJSON();

            if (storedMessageTexts.isEmpty()) {

                System.out.println(
                        "No stored messages available."
                );

                return;
            }

            boolean inMenu = true;

            while (inMenu) {

                System.out.println(
                        "\n========== STORED MESSAGES MENU =========="
                );

                System.out.println(
                        "a) Display sender and recipient"
                );

                System.out.println(
                        "b) Display longest stored message"
                );

                System.out.println(
                        "c) Search by Message ID"
                );

                System.out.println(
                        "d) Search by Recipient"
                );

                System.out.println(
                        "e) Delete by Message Hash"
                );

                System.out.println(
                        "f) Display Full Report"
                );

                System.out.println(
                        "g) Back to Main Menu"
                );

                System.out.print(
                        "Choose option: "
                );

                String choice =
                        scanner.nextLine()
                               .trim()
                               .toLowerCase();

                switch (choice) {

                    case "a":
                        displayStoredSenderRecipient();
                        break;

                    case "b":
                        displayLongestStoredMessage();
                        break;

                    case "c":
                        searchByMessageID();
                        break;

                    case "d":
                        searchByRecipient();
                        break;

                    case "e":
                        deleteByMessageHash();
                        break;

                    case "f":
                        displayFullReport();
                        break;

                    case "g":
                        inMenu = false;
                        break;

                    default:
                        System.out.println(
                                "Invalid option."
                        );
                }
            }
        }

        // =================================================
        // OPTION A
        // DISPLAY SENDER AND RECIPIENT
        // =================================================

        private static void displayStoredSenderRecipient() {

            System.out.println(
                    "\n======= STORED MESSAGE DETAILS ======="
            );

            for (int i = 0;
                    i < storedMessageTexts.size();
                    i++) {

                System.out.println(
                        "\nMessage " + (i + 1)
                );

                System.out.println(
                        "Sender    : "
                        + storedSenders.get(i)
                );

                System.out.println(
                        "Recipient : "
                        + storedRecipients.get(i)
                );

                System.out.println(
                        "--------------------------------"
                );
            }
        }

        // =================================================
        // OPTION B
        // DISPLAY LONGEST MESSAGE
        // =================================================

        private static void displayLongestStoredMessage() {

            int longestIndex = 0;

            for (int i = 1;
                    i < storedMessageTexts.size();
                    i++) {

                if (storedMessageTexts.get(i).length()
                        >
                    storedMessageTexts
                            .get(longestIndex)
                            .length()) {

                    longestIndex = i;
                }
            }

            System.out.println(
                    "\n===== LONGEST STORED MESSAGE ====="
            );

            System.out.println(
                    storedMessageTexts.get(longestIndex)
            );
        }

        // =================================================
        // OPTION C
        // SEARCH BY MESSAGE ID
        // =================================================

        private static void searchByMessageID() {

            System.out.print(
                    "Enter Message ID: "
            );

            String searchID =
                    scanner.nextLine().trim();

            boolean found = false;

            for (int i = 0;
                    i < storedMessageIDs.size();
                    i++) {

                if (storedMessageIDs.get(i)
                        .equals(searchID)) {

                    System.out.println(
                            "\nRecipient : "
                            + storedRecipients.get(i)
                    );

                    System.out.println(
                            "Message   : "
                            + storedMessageTexts.get(i)
                    );

                    found = true;

                    break;
                }
            }

            if (!found) {

                System.out.println(
                        "No message found."
                );
            }
        }

        // =================================================
        // OPTION D
        // SEARCH BY RECIPIENT
        // =================================================

        private static void searchByRecipient() {

            System.out.print(
                    "Enter recipient number: "
            );

            String searchRecipient =
                    scanner.nextLine().trim();

            boolean found = false;

            for (int i = 0;
                    i < storedRecipients.size();
                    i++) {

                if (storedRecipients.get(i)
                        .equalsIgnoreCase(
                                searchRecipient
                        )) {

                    System.out.println(
                            "\nMessage ID : "
                            + storedMessageIDs.get(i)
                    );

                    System.out.println(
                            "Message    : "
                            + storedMessageTexts.get(i)
                    );

                    found = true;
                }
            }

            if (!found) {

                System.out.println(
                        "No messages found."
                );
            }
        }

        // =================================================
        // OPTION E
        // DELETE BY HASH
        // =================================================

        private static void deleteByMessageHash() {

            System.out.print(
                    "Enter Message Hash: "
            );

            String hash =
                    scanner.nextLine().trim();

            for (int i = 0;
                    i < storedMessageHashes.size();
                    i++) {

                if (storedMessageHashes.get(i)
                        .equalsIgnoreCase(hash)) {

                    String deletedMessage =
                            storedMessageTexts.get(i);

                    storedMessageTexts.remove(i);
                    storedRecipients.remove(i);
                    storedMessageIDs.remove(i);
                    storedMessageHashes.remove(i);
                    storedSenders.remove(i);

                    System.out.println(
                            "Message deleted:"
                    );

                    System.out.println(
                            deletedMessage
                    );

                    return;
                }
            }

            System.out.println(
                    "No message found."
            );
        }

        // =================================================
        // OPTION F
        // FULL REPORT
        // =================================================

        private static void displayFullReport() {

            System.out.println(
                    "\n============= FULL REPORT ============="
            );

            for (int i = 0;
                    i < storedMessageTexts.size();
                    i++) {

                System.out.println(
                        "\nMessage " + (i + 1)
                );

                System.out.println(
                        "Message ID   : "
                        + storedMessageIDs.get(i)
                );

                System.out.println(
                        "Message Hash : "
                        + storedMessageHashes.get(i)
                );

                System.out.println(
                        "Sender       : "
                        + storedSenders.get(i)
                );

                System.out.println(
                        "Recipient    : "
                        + storedRecipients.get(i)
                );

                System.out.println(
                        "Message      : "
                        + storedMessageTexts.get(i)
                );

                System.out.println(
                        "--------------------------------------"
                );
            }
        }

        // =================================================
        // LOAD STORED MESSAGES FROM JSON
        // =================================================

        public static void loadStoredMessagesFromJSON() {

            String filePath = "messages.json";

            try {

                String content =
                        new String(
                                Files.readAllBytes(
                                        Paths.get(filePath)
                                )
                        );

                int startIndex =
                        content.indexOf(
                                "\"stored_messages\""
                        );

                if (startIndex == -1) {
                    return;
                }

                int arrayOpen =
                        content.indexOf(
                                "[",
                                startIndex
                        );

                int arrayClose =
                        content.indexOf(
                                "]",
                                arrayOpen
                        );

                if (arrayOpen == -1
                        || arrayClose == -1) {

                    return;
                }

                String storedSection =
                        content.substring(
                                arrayOpen,
                                arrayClose + 1
                        );

                int position = 0;

                while (true) {

                    int blockStart =
                            storedSection.indexOf(
                                    "{",
                                    position
                            );

                    if (blockStart == -1) {
                        break;
                    }

                    int blockEnd =
                            storedSection.indexOf(
                                    "}",
                                    blockStart
                            );

                    if (blockEnd == -1) {
                        break;
                    }

                    String block =
                            storedSection.substring(
                                    blockStart,
                                    blockEnd + 1
                            );

                    String sender =
                            extractJSONValue(
                                    block,
                                    "sender"
                            );

                    String id =
                            extractJSONValue(
                                    block,
                                    "messageID"
                            );

                    String hash =
                            extractJSONValue(
                                    block,
                                    "messageHash"
                            );

                    String recipient =
                            extractJSONValue(
                                    block,
                                    "recipient"
                            );

                    String message =
                            extractJSONValue(
                                    block,
                                    "message"
                            );

                    if (id != null
                            && !storedMessageIDs.contains(id)) {

                        storedSenders.add(sender);
                        storedMessageIDs.add(id);
                        storedMessageHashes.add(hash);
                        storedRecipients.add(recipient);
                        storedMessageTexts.add(message);
                    }

                    position = blockEnd + 1;
                }

            } catch (IOException e) {

                System.out.println(
                        "Could not read JSON file."
                );
            }
        }

        // =================================================
        // EXTRACT VALUE FROM JSON STRING
        // =================================================

        private static String extractJSONValue(
                String block,
                String key) {

            String searchKey =
                    "\"" + key + "\"";

            int keyIndex =
                    block.indexOf(searchKey);

            if (keyIndex == -1) {
                return null;
            }

            int colon =
                    block.indexOf(
                            ":",
                            keyIndex
                    );

            int quoteOpen =
                    block.indexOf(
                            "\"",
                            colon
                    );

            int quoteClose =
                    block.indexOf(
                            "\"",
                            quoteOpen + 1
                    );

            if (quoteOpen == -1
                    || quoteClose == -1) {

                return null;
            }

            return block.substring(
                    quoteOpen + 1,
                    quoteClose
            );
        }

        // =================================================
        // TOTAL MESSAGE COUNT
        // =================================================

        public static int getTotalMessages() {

            return sentMessages.size()
                    + storedMessages.size();
        }

        // =================================================
        // TOTAL SENT MESSAGE COUNT
        // =================================================

        public static int getSentMessageCount() {

            return sentMessages.size();
        }

        // =================================================
        // SAVE ALL MESSAGES TO JSON
        // =================================================

        public static void saveMessagesToJSON() {

            StringBuilder json =
                    new StringBuilder();

            json.append("{\n");

            json.append(
                    "  \"stored_messages\": [\n"
            );

            for (int i = 0;
                    i < storedMessageIDs.size();
                    i++) {

                json.append(
                        buildJSONObject(
                                storedSenders.get(i),
                                storedMessageIDs.get(i),
                                storedMessageHashes.get(i),
                                storedRecipients.get(i),
                                storedMessageTexts.get(i),
                                "Stored"
                        )
                );

                if (i < storedMessageIDs.size() - 1) {
                    json.append(",");
                }

                json.append("\n");
            }

            json.append("  ]\n");
            json.append("}");

            try (FileWriter writer =
                         new FileWriter(
                                 "messages.json"
                         )) {

                writer.write(
                        json.toString()
                );

                System.out.println(
                        "Messages saved to messages.json"
                );

            } catch (IOException e) {

                System.out.println(
                        "Error saving file."
                );
            }
        }

        // =================================================
        // BUILD JSON OBJECT
        // =================================================

        private static String buildJSONObject(
                String sender,
                String id,
                String hash,
                String recipient,
                String message,
                String status) {

            return """
                    {
                      "sender":"%s",
                      "messageID":"%s",
                      "messageHash":"%s",
                      "recipient":"%s",
                      "message":"%s",
                      "status":"%s"
                    }
                    """.formatted(
                    escape(sender),
                    escape(id),
                    escape(hash),
                    escape(recipient),
                    escape(message),
                    escape(status)
            );
        }

        // =================================================
        // ESCAPE JSON CHARACTERS
        // =================================================

        private static String escape(String text) {

            return text
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
        }

    // =================================================
// TEST SUPPORT METHODS
// =================================================

public static void clearAllData() {

    sentMessagesArray.clear();
    disregardedMessagesArray.clear();
    storedMessagesArray.clear();

    messageHashesArray.clear();
    messageIDsArray.clear();

    sentMessageTexts.clear();
    sentRecipients.clear();
    sentMessageIDs.clear();
    sentMessageHashes.clear();

    storedMessageTexts.clear();
    storedRecipients.clear();
    storedMessageIDs.clear();
    storedMessageHashes.clear();
    storedSenders.clear();
}

public static void addTestMessage(
        String sender,
        String recipient,
        String message,
        String id,
        String hash,
        String flag) {

    if (flag.equalsIgnoreCase("Sent")) {

        sentMessageTexts.add(message);
        sentRecipients.add(recipient);
        sentMessageIDs.add(id);
        sentMessageHashes.add(hash);
        sentMessagesArray.add(message);

    } else if (flag.equalsIgnoreCase("Stored")) {

        storedMessageTexts.add(message);
        storedRecipients.add(recipient);
        storedMessageIDs.add(id);
        storedMessageHashes.add(hash);
        storedSenders.add(sender);
        storedMessagesArray.add(message);

    } else if (flag.equalsIgnoreCase("Disregard")) {

        disregardedMessagesArray.add(message);
    }
}

public static List<String> getSentMessagesArray() {
    return sentMessagesArray;
}

public static String getLongestMessage() {

    String longest = "";

    for (String msg : storedMessageTexts) {

        if (msg.length() > longest.length()) {
            longest = msg;
        }
    }

    return longest;
}

public static String searchMessageByID(String id) {

    for (int i = 0; i < storedMessageIDs.size(); i++) {

        if (storedMessageIDs.get(i).equals(id)) {
            return storedMessageTexts.get(i);
        }
    }

    return null;
}

public static List<String> searchMessagesByRecipient(
        String recipient) {

    List<String> results = new ArrayList<>();

    for (int i = 0; i < storedRecipients.size(); i++) {

        if (storedRecipients.get(i).equals(recipient)) {

            results.add(
                    storedMessageTexts.get(i)
            );
        }
    }

    return results;
}

public static boolean deleteMessageByHash(
        String hash) {

    for (int i = 0; i < storedMessageHashes.size(); i++) {

        if (storedMessageHashes.get(i)
                .equalsIgnoreCase(hash)) {

            storedMessageTexts.remove(i);
            storedRecipients.remove(i);
            storedMessageIDs.remove(i);
            storedMessageHashes.remove(i);
            storedSenders.remove(i);

            return true;
        }
    }

    return false;
}

public static String generateReport() {

    StringBuilder report =
            new StringBuilder();

    for (int i = 0; i < storedMessageTexts.size(); i++) {

        report.append("Message Hash: ")
              .append(storedMessageHashes.get(i))
              .append("\n");

        report.append("Recipient: ")
              .append(storedRecipients.get(i))
              .append("\n");

        report.append("Message: ")
              .append(storedMessageTexts.get(i))
              .append("\n\n");
    }

    return report.toString();
}    
    } // END OF MESSAGE CLASS

} 