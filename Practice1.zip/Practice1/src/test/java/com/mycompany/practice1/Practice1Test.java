package com.mycompany.practice1;

import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Practice1Test {

@BeforeEach
public void setUp() {

    Practice1.Message.clearAllData();

    // Message 1 (Sent)
    Practice1.Message.addTestMessage(
            "user_",
            "+27834557896",
            "Did you get the cake?",
            "1111111111",
            "11:1:DIDCAKE",
            "Sent"
    );

    // Message 2 (Stored)
    Practice1.Message.addTestMessage(
            "user_",
            "+27838884567",
            "Where are you? You are late! I have asked you to be on time.",
            "2222222222",
            "22:2:WHERETIME",
            "Stored"
    );

    // Message 3 (Disregarded)
    Practice1.Message.addTestMessage(
            "user_",
            "+27834484567",
            "Yohoooo, I am at your gate.",
            "3333333333",
            "33:3:YOHOOOOGATE",
            "Disregard"
    );

    // Message 4 (Sent)
    Practice1.Message.addTestMessage(
            "developer",
            "0838884567",
            "It is dinner time!",
            "0838884567",
            "44:4:ITTIME",
            "Sent"
    );

    // Message 5 (Stored)
    Practice1.Message.addTestMessage(
            "user_",
            "+27838884567",
            "Ok, I am leaving without you.",
            "5555555555",
            "55:5:OKYOU",
            "Stored"
    );
}

@Test
public void testSentMessagesArrayCorrectlyPopulated() {

    List<String> sentMessages =
            Practice1.Message.getSentMessagesArray();

    assertEquals(2, sentMessages.size());

    assertEquals(
            "Did you get the cake?",
            sentMessages.get(0)
    );

    assertEquals(
            "It is dinner time!",
            sentMessages.get(1)
    );
}

@Test
public void testDisplayLongestMessage() {

    String longest =
            Practice1.Message.getLongestMessage();

    assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest
    );
}

@Test
public void testSearchForMessageID() {

    String message =
            Practice1.Message.searchMessageByID(
                    "0838884567"
            );

    assertEquals(
            "It is dinner time!",
            message
    );
}

@Test
public void testSearchMessagesByRecipient() {

    List<String> messages =
            Practice1.Message.searchMessagesByRecipient(
                    "+27838884567"
            );

    assertEquals(2, messages.size());

    assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            messages.get(0)
    );

    assertEquals(
            "Ok, I am leaving without you.",
            messages.get(1)
    );
}

@Test
public void testDeleteMessageUsingHash() {

    boolean deleted =
            Practice1.Message.deleteMessageByHash(
                    "22:2:WHERETIME"
            );

    assertTrue(deleted);
}

@Test
public void testDisplayReport() {

    String report =
            Practice1.Message.generateReport();

    assertTrue(report.contains("Message Hash"));
    assertTrue(report.contains("Recipient"));
    assertTrue(report.contains("Message"));
}

}
